<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Controller;
use App\Category;

class CategoryController extends Controller
{
    // Form page
    public function index() {
        $categories = Category::all();
        return view('Frontend.category.index', compact('categories'));
    }
    public function add(Request $request){
        $cat = new Category();
        $cat->name = $request->input('name');

        if($request->hasFile('pic')){
            $file = $request->file('pic');
            $ext = $file->getClientOriginalExtension();
            $filename = 'category_'.time().'.'.$ext;
            $file->move('uploads/category/',$filename);
            $cat->picture = $filename;
        }
        $cat->save();

        return redirect('/categories')->with('alert', 'Category added successfully');
    }
    public function view($id){
        $cat = Category::find($id);
        return view('Frontend.category.edit', compact('cat'));
    }
    public function update($id, Request $request){
        $cat = Category::find($id);

        $cat->name = $request->input('name');

        $path = 'uploads/category/'.$cat->picture;

        if($request->hasFile('pic'))
        {
            if(File::exists($path)){
                File::delete($path);
            }
            $file = $request->file('pic');
            $ext = $file->getClientOriginalExtension();
            $filename = 'category_'.time().'.'.$ext;
            $file->move('uploads/category/',$filename);
            $cat->picture = $filename;
        }
        $cat->update();

        return redirect('/categories')->with('alert', 'Category updated successfully');
    }
}
