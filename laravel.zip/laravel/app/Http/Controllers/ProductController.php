<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\ProductImage;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function store(Request $request){

        $rules = [
            'image' => 'required',
            'title' => 'required',
           ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
           return response()->json(['message' => $validator->errors()->all()], 400);
        }

        try {
            $imageID = time(). mt_rand(1111, 9999);
            Product::create([
                'title' => $request->title,
                'image' => $imageID
            ]);

            $images = Input::file('image');
            foreach ($images as $image) {
                $ext = $image->extension();
                $imageName = time(). mt_rand(1111, 9999).'.'.$ext;
                $uploadFile = $image->move('uploads/', $imageName);

                ProductImage::create([
                    'image_id' => $imageID,
                    'image' => $imageName
                ]);
            }
            return response()->json(['message' => 'Success'], 200);
        } catch (\Throwable $th) {
            return response()->json(['message' => $th->getMessage()], 500,);
        }
    }
    public function view($id)
    {
        $item = Product::find($id);
        $images = $item->images;
        return view('view', compact('images'));
    }
}
