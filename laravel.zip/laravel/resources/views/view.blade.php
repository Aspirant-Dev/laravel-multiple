@extends('layouts.app')
@section('content')

@foreach ($images as $image)
    <img src="{{ asset('uploads/'.$image->image) }}" alt="" srcset="">

@endforeach
@endsection
