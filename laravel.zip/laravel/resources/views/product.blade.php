@extends('layouts.app')

@section('content')
<div class="container">

    <form action="" enctype="multipart/form-data" id="multiImage">
        {{ csrf_field() }}
        <div class="form-group">
          <label for="title">Title</label>
          <input type="text" class="form-control" name="title" id="title" placeholder="Enter product title">
        </div>
        <input type="file filepond"
                class="filepond"
                name="image[]"
                multiple
                data-max-files="3"
                id="uploadImage"
        />
        <button class="btn btn-success btnSubmit">Save</button>
    </form>
    <table class="table table-dark">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            @if ($products->count() > 0)
                @foreach ($products as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->title }}</td>
                        <td><a href="{{ url('view/'.$item->id) }}">View</a></td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td>No data</td>
                </tr>
            @endif
        </tbody>
      </table>
</div>
@endsection
@section('script')
<script>
    //FILE UPLOAD USING FILEPOND JS
    const inputElement = document.getElementById("uploadImage");
    const Pond = FilePond.create(inputElement);
    const frm = document.getElementById("multiImage");

    var request = new XMLHttpRequest();

    frm.addEventListener('submit', function (e) {
        e.preventDefault();
        var frmData = new FormData(frm);

        pondFiles = Pond.getFiles();
        for (var i = 0; i < pondFiles.length; i++) {
            frmData.append('image[]', pondFiles[i].file);
        }

        request.onload = function () {
            if(this.status == 200){
                var data = JSON.parse(this.responseText);

                alert(data.message);
            }
            else if(this.status == 400){
                var data = JSON.parse(this.responseText);
                alert(data.message);
            }
            else if(this.status == 500){
                var data = JSON.parse(this.responseText);

                alert(data.message);
            }
        };

        request.open('post', '{{ route("add.product") }}');
        request.send(frmData);
    },false);
</script>
@endsection
