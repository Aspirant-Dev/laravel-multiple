<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Category</title>

    <!--- CSS -->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <div class="container">
        @if(session('alert'))
        <div class="alert alert-success">
            {{ session('alert') }}
        </div>
        @endif
        <h1>Categories</h1>
        <table class="table">
            <thead class="text-center">
                <th>ID</th>
                <th>Name</th>
                <th>Image</th>
                <th>Action</th>
            </thead>
            <tbody>
                @foreach ($categories as $item)
                    <tr class="text-center">
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->name }}</td>
                        <td><img src="{{ asset('uploads/category/'.$item->picture) }}" alt="{{ $item->picture }}" height="50px" width="50px"></td>
                        <td>
                            <a href="/category/view/{{ $item->id }}">View</a>
                            <a href="">Delete</a>
                        </td>
                    </tr>
                @endforeach

                <form action="{{ route('category.submit') }}" method="post" enctype="multipart/form-data">
                    @csrf

                    <div class="row">
                        <div class="col-md-6">
                            <label>Category Name</label>
                            <input type="text" name="name" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Image</label>
                            <input type="file" name="pic" class="form-control" />
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </tbody>
        </table>
    </div>
</body>
</html>
