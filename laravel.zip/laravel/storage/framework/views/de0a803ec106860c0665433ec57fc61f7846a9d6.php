<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Category</title>

    <!--- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="container">
        <?php if(session('alert')): ?>
        <div class="alert alert-success">
            <?php echo e(session('alert')); ?>

        </div>
        <?php endif; ?>
        <h1>Categories</h1>
        <table class="table">
            <thead class="text-center">
                <th>ID</th>
                <th>Name</th>
                <th>Image</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><img src="<?php echo e(asset('uploads/category/'.$item->picture)); ?>" alt="<?php echo e($item->picture); ?>" height="50px" width="50px"></td>
                        <td>
                            <a href="/category/view/<?php echo e($item->id); ?>">View</a>
                            <a href="">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <form action="<?php echo e(route('category.submit')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <label>Category Name</label>
                            <input type="text" name="name" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Image</label>
                            <input type="file" name="pic" class="form-control" />
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/Frontend/category/index.blade.php ENDPATH**/ ?>