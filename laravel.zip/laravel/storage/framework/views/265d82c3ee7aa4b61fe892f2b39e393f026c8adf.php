<?php $__env->startSection('content'); ?>
<div class="container">

    <form action="" enctype="multipart/form-data" id="multiImage">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="title">Title</label>
          <input type="text" class="form-control" name="title" id="title" placeholder="Enter product title">
        </div>
        <input type="file filepond"
                class="filepond"
                name="image[]"
                multiple
                data-max-files="3"
                id="uploadImage"
        />
        <button class="btn btn-success btnSubmit">Save</button>
    </form>
    <table class="table table-dark">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            <?php if($products->count() > 0): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td><a href="<?php echo e(url('view/'.$item->id)); ?>">View</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td>No data</td>
                </tr>
            <?php endif; ?>
        </tbody>
      </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    //FILE UPLOAD USING FILEPOND JS
    const inputElement = document.getElementById("uploadImage");
    const Pond = FilePond.create(inputElement);
    const frm = document.getElementById("multiImage");

    var request = new XMLHttpRequest();

    frm.addEventListener('submit', function (e) {
        e.preventDefault();
        var frmData = new FormData(frm);

        pondFiles = Pond.getFiles();
        for (var i = 0; i < pondFiles.length; i++) {
            frmData.append('image[]', pondFiles[i].file);
        }

        request.onload = function () {
            if(this.status == 200){
                var data = JSON.parse(this.responseText);

                alert(data.message);
            }
            else if(this.status == 400){
                var data = JSON.parse(this.responseText);
                alert(data.message);
            }
            else if(this.status == 500){
                var data = JSON.parse(this.responseText);

                alert(data.message);
            }
        };

        request.open('post', '<?php echo e(route("add.product")); ?>');
        request.send(frmData);
    },false);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/product.blade.php ENDPATH**/ ?>