<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(Str::ucfirst($cat->name)); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="container">
        <h1 class="mt-2"><?php echo e($cat->name); ?></h1>

        <form action="/category/update/<?php echo e($cat->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Name: </label>
                <input type="text" value="<?php echo e($cat->name); ?>" name="name" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Image: </label> <br>
                <img src="<?php echo e(asset('uploads/category/'.$cat->picture)); ?>" alt="" height="120px" width="120px"><br>
                <input type="file" class="form-file-control" name="pic">
            </div>
            <button type="submit" class="btn btn-success">Update</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/Frontend/category/edit.blade.php ENDPATH**/ ?>